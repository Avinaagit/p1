UPDATE User SET email = 'consultant@company.com' WHERE email = 'admin@company.com';
