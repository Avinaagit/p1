UPDATE User SET role = 'HR' WHERE email = 'hr@company.com';
