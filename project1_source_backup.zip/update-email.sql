UPDATE User SET email = 'hr@company.com' WHERE email = 'consultant@company.com';
